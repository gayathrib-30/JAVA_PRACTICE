package song;
import movie.Leo;
public class Ready
{
    public String singer="ani";
    public static void main(String[] args) {
        Ready r=new Ready();
        System.out.println("Iam in song package,singer name " + r.singer);
        Leo l2=new Leo();
        System.out.println("Iam in movie package,actor name "+ l2.actorname);
    }
}
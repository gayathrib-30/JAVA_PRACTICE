package movie;
public class Leo
{
    public String actorname="vijay";
    public static void main(String[] args) {
        Leo l1=new Leo();
        System.out.println("Iam in movie package,actor name "+l1.actorname);
    }
}